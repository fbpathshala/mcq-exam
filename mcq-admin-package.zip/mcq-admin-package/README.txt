MCQ Exam Admin package

Upload/replace these files in the same GitHub Pages folder:
- admin.html — admin dashboard
- student_exam.html — student exam page (if already present, keep your current version)

The admin dashboard now uses separate sections through the three-dot menu. Only the selected section is shown.

Important: Supabase database policies and tables remain unchanged.
